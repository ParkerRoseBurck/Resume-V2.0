package ScrabblePointsGenerator;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

import java.util.ArrayList;

public class Controller {


    @FXML
    private Button submitButton;
    @FXML
    private TextField newWord;
    @FXML
    private Label previousWords;
    @FXML
    private Label a;
    @FXML
    private Label b;
    @FXML
    private Label c;
    @FXML
    private Label d;
    @FXML
    private Label e;
    @FXML
    private Label f;
    @FXML
    private Label g;
    @FXML
    private Label h;
    @FXML
    private Label i;
    @FXML
    private Label j;
    @FXML
    private Label k;
    @FXML
    private Label l;
    @FXML
    private Label m;
    @FXML
    private Label n;
    @FXML
    private Label o;
    @FXML
    private Label p;
    @FXML
    private Label q;
    @FXML
    private Label r;
    @FXML
    private Label s;
    @FXML
    private Label t;
    @FXML
    private Label u;
    @FXML
    private Label v;
    @FXML
    private Label w;
    @FXML
    private Label x;
    @FXML
    private Label y;
    @FXML
    private Label z;
    @FXML
    private Label points;
    @FXML
    private Button buttonA;
    @FXML
    private Button buttonB;
    @FXML
    private Button buttonC;
    @FXML
    private Button buttonD;
    @FXML
    private Button buttonE;
    @FXML
    private Button buttonF;
    @FXML
    private Button buttonG;
    @FXML
    private Button buttonH;
    @FXML
    private Button buttonI;
    @FXML
    private Button buttonJ;
    @FXML
    private Button buttonK;
    @FXML
    private Button buttonL;
    @FXML
    private Button buttonM;
    @FXML
    private Button buttonN;
    @FXML
    private Button buttonO;
    @FXML
    private Button buttonP;
    @FXML
    private Button buttonQ;
    @FXML
    private Button buttonR;
    @FXML
    private Button buttonS;
    @FXML
    private Button buttonT;
    @FXML
    private Button buttonU;
    @FXML
    private Button buttonV;
    @FXML
    private Button buttonW;
    @FXML
    private Button buttonX;
    @FXML
    private Button buttonY;
    @FXML
    private Button buttonZ;
    @FXML
    private Label errorMsg;

    ArrayList wordsUsed = new ArrayList();
    int vowelsLeft = 43;
    int tilesLeft = 97;
    public void submitClicked(ActionEvent actionEvent){
        var word = newWord.getText();
        word = word.toUpperCase();
        System.out.println(word);
        var validWord = true;
        var wordTotal = 0;
        var vowel = false;
        var unused = true;

        if((word.length() >= 2) && (word.length() <= 8)) {

            for (var count = 0; count < word.length(); count++) {
                var letter = word.charAt(count);
                int amount;
                String newAmount;
                switch(letter){
                    case 'A':
                        vowel = true;
                        var amountA = a.getText();
                        amount = Integer.parseInt(amountA);
                        if(amount == 0) {
                            validWord = false;
                        }
                            amount -= 1;
                            newAmount = Integer.toString(amount);
                            a.setText(newAmount);
                            tilesLeft -= 1;
                            vowelsLeft -= 1;
                        wordTotal += 1;
                        break;
                    case 'B':
                        var amountB = b.getText();
                        amount = Integer.parseInt(amountB);
                        if(amount == 0) {
                            validWord = false;
                        }
                            amount -= 1;
                            newAmount = Integer.toString(amount);
                            b.setText(newAmount);
                        tilesLeft -= 1;


                        wordTotal += 3;
                        break;
                    case 'C':
                        var amountC = c.getText();
                        amount = Integer.parseInt(amountC);
                        if(amount == 0) {
                            validWord = false;
                        }
                            amount -= 1;
                            newAmount = Integer.toString(amount);
                            c.setText(newAmount);
                        tilesLeft -= 1;


                        wordTotal += 3;
                        break;
                    case 'D':
                        var amountD = d.getText();
                        amount = Integer.parseInt(amountD);
                        if(amount == 0) {
                            validWord = false;
                        }
                            amount -= 1;
                            newAmount = Integer.toString(amount);
                            d.setText(newAmount);
                        tilesLeft -= 1;


                        wordTotal += 2;
                        break;
                    case 'E':
                        vowel = true;
                        var amountE = e.getText();
                        amount = Integer.parseInt(amountE);
                        if(amount == 0) {
                            validWord = false;
                        }
                            amount -= 1;
                            newAmount = Integer.toString(amount);
                            e.setText(newAmount);
                        tilesLeft -= 1;
                        vowelsLeft -= 1;

                        wordTotal += 1;
                        break;
                    case 'F':
                        var amountF = f.getText();
                        amount = Integer.parseInt(amountF);
                        if(amount == 0) {
                            validWord = false;
                        }
                            amount -= 1;
                            newAmount = Integer.toString(amount);
                            f.setText(newAmount);
                        tilesLeft -= 1;


                        wordTotal += 4;
                        break;
                    case 'G':
                        var amountG = g.getText();
                        amount = Integer.parseInt(amountG);
                        if(amount == 0) {
                            validWord = false;
                        }
                            amount -= 1;
                            newAmount = Integer.toString(amount);
                            g.setText(newAmount);
                        tilesLeft -= 1;


                        wordTotal += 2;
                        break;
                    case 'H':
                        var amountH = h.getText();
                        amount = Integer.parseInt(amountH);
                        if(amount == 0) {
                            validWord = false;
                        }
                            amount -= 1;
                            newAmount = Integer.toString(amount);
                            h.setText(newAmount);
                        tilesLeft -= 1;


                        wordTotal += 4;
                        break;
                    case 'I':
                        vowel = true;
                        var amountI = i.getText();
                        amount = Integer.parseInt(amountI);
                        if(amount == 0) {
                            validWord = false;
                        }
                            amount -= 1;
                            newAmount = Integer.toString(amount);
                            i.setText(newAmount);
                        tilesLeft -= 1;
                        vowelsLeft -= 1;

                        wordTotal += 1;
                        break;
                    case 'J':
                        var amountJ = j.getText();
                        amount = Integer.parseInt(amountJ);
                        if(amount == 0) {
                            validWord = false;
                        }
                            amount -= 1;
                            newAmount = Integer.toString(amount);
                            j.setText(newAmount);
                        tilesLeft -= 1;


                        wordTotal += 8;
                        break;
                    case 'K':
                        var amountK = k.getText();
                        amount = Integer.parseInt(amountK);
                        if(amount == 0) {
                            validWord = false;
                        }
                            amount -= 1;
                            newAmount = Integer.toString(amount);
                            k.setText(newAmount);
                        tilesLeft -= 1;


                        wordTotal += 5;
                        break;
                    case 'L':
                        var amountL = l.getText();
                        amount = Integer.parseInt(amountL);
                        if(amount == 0) {
                            validWord = false;
                        }
                            amount -= 1;
                            newAmount = Integer.toString(amount);
                            l.setText(newAmount);
                        tilesLeft -= 1;


                        wordTotal += 1;
                        break;
                    case 'M':
                        var amountM = m.getText();
                        amount = Integer.parseInt(amountM);
                        if(amount == 0) {
                            validWord = false;
                        }
                            amount -= 1;
                            newAmount = Integer.toString(amount);
                            m.setText(newAmount);
                        tilesLeft -= 1;


                        wordTotal += 3;
                        break;
                    case 'N':
                        var amountN = n.getText();
                        amount = Integer.parseInt(amountN);
                        if(amount == 0) {
                            validWord = false;
                        }
                            amount -= 1;
                            newAmount = Integer.toString(amount);
                            n.setText(newAmount);
                        tilesLeft -= 1;


                        wordTotal += 1;
                        break;
                    case 'O':
                        vowel = true;
                        var amountO = o.getText();
                        amount = Integer.parseInt(amountO);
                        if(amount == 0) {
                            validWord = false;
                        }
                            amount -= 1;
                            newAmount = Integer.toString(amount);
                            o.setText(newAmount);
                        tilesLeft -= 1;
                        vowelsLeft -= 1;

                        wordTotal += 1;
                        break;
                    case 'P':
                        var amountP = p.getText();
                        amount = Integer.parseInt(amountP);
                        if(amount == 0) {
                            validWord = false;
                        }
                            amount -= 1;
                            newAmount = Integer.toString(amount);
                            p.setText(newAmount);
                        tilesLeft -= 1;


                        wordTotal += 3;
                        break;
                    case 'Q':
                        var amountQ = q.getText();
                        amount = Integer.parseInt(amountQ);
                        if(amount == 0) {
                            validWord = false;
                        }
                            amount -= 1;
                            newAmount = Integer.toString(amount);
                            q.setText(newAmount);
                        tilesLeft -= 1;


                        wordTotal += 10;
                        break;
                    case 'R':
                        var amountR = r.getText();
                        amount = Integer.parseInt(amountR);
                        if(amount == 0) {
                            validWord = false;
                        }
                            amount -= 1;
                            newAmount = Integer.toString(amount);
                            r.setText(newAmount);
                        tilesLeft -= 1;


                        wordTotal += 1;
                        break;
                    case 'S':
                        var amountS = s.getText();
                        amount = Integer.parseInt(amountS);
                        if(amount == 0) {
                            validWord = false;
                        }
                            amount -= 1;
                            newAmount = Integer.toString(amount);
                            s.setText(newAmount);
                        tilesLeft -= 1;


                        wordTotal += 1;
                        break;
                    case 'T':
                        var amountT = t.getText();
                        amount = Integer.parseInt(amountT);
                        if(amount == 0) {
                            validWord = false;
                        }
                            amount -= 1;
                            newAmount = Integer.toString(amount);
                            t.setText(newAmount);
                        tilesLeft -= 1;


                        wordTotal += 1;
                        break;
                    case 'U':
                        vowel = true;
                        var amountU = u.getText();
                        amount = Integer.parseInt(amountU);
                        if(amount == 0) {
                            validWord = false;
                        }
                            amount -= 1;
                            newAmount = Integer.toString(amount);
                            u.setText(newAmount);
                        tilesLeft -= 1;
                        vowelsLeft -= 1;

                        wordTotal += 1;
                        break;
                    case 'V':
                        var amountV = v.getText();
                        amount = Integer.parseInt(amountV);
                        if(amount == 0) {
                            validWord = false;
                        }
                            amount -= 1;
                            newAmount = Integer.toString(amount);
                            v.setText(newAmount);
                        tilesLeft -= 1;


                        wordTotal += 4;
                        break;
                    case 'W':
                        var amountW = w.getText();
                        amount = Integer.parseInt(amountW);
                        if(amount == 0) {
                            validWord = false;
                        }
                            amount -= 1;
                            newAmount = Integer.toString(amount);
                            w.setText(newAmount);
                        tilesLeft -= 1;


                        wordTotal += 4;
                        break;
                    case 'X':
                        var amountX = x.getText();
                        amount = Integer.parseInt(amountX);
                        if(amount == 0) {
                            validWord = false;
                        }
                            amount -= 1;
                            newAmount = Integer.toString(amount);
                            x.setText(newAmount);
                        tilesLeft -= 1;


                        wordTotal += 8;
                        break;
                    case 'Y':
                        vowel = true;
                        var amountY = y.getText();
                        amount = Integer.parseInt(amountY);
                        if(amount == 0) {
                            validWord = false;
                        }
                            amount -= 1;
                            newAmount = Integer.toString(amount);
                            y.setText(newAmount);
                        tilesLeft -= 1;
                        vowelsLeft -= 1;

                        wordTotal += 4;
                        break;
                    case 'Z':
                        var amountZ = z.getText();
                        amount = Integer.parseInt(amountZ);
                        if(amount == 0) {
                            validWord = false;
                        }
                            amount -= 1;
                            newAmount = Integer.toString(amount);
                            z.setText(newAmount);
                        tilesLeft -= 1;


                        wordTotal += 10;
                        break;
                }




            }





            for(int count = 0; count < wordsUsed.size(); count ++){
                System.out.println("In the for loop for the array list");
                System.out.println(wordsUsed.get(count));
                if(word.equals(wordsUsed.get(count))){
                    System.out.println("In the if loop for duplicates");
                    unused = false;
                    System.out.println("Duplicate word: " + wordsUsed.get(count));
                    System.out.println(unused);
                }
            }



            if(validWord && vowel && unused){

                var oldWords = previousWords.getText();
                var allWords = oldWords + ", " + word;
                previousWords.setText(allWords);
                wordsUsed.add(word);

                var total = points.getText();
                var numberTotal = Integer.parseInt(total);
                var newTotal = numberTotal + wordTotal;
                String newStringTotal = Integer.toString(newTotal);
                points.setText(newStringTotal);

                //set error output back to blank if its a valid word
                errorMsg.setText("");
                System.out.println("tiles: " + tilesLeft);
                System.out.println("Vowels: " + vowelsLeft);
                // if the word is valid, grey out any letters that are not longer usable
                //also count the number of tiles used and minus from total
                //also separately count the number of vowels used and minus that from vowel total
                for (var count = 0; count < word.length(); count++) {
                    var letter = word.charAt(count);
                    int amount;


                    switch(letter){
                        case 'A':
                            var amountA = a.getText();
                            amount = Integer.parseInt(amountA);
                            if(amount == 0){
                                buttonA.setStyle("-fx-background-color: #B6D7C6");
                            }
                            break;
                        case 'B':
                            var amountB = b.getText();
                            amount = Integer.parseInt(amountB);
                            if(amount == 0){
                                buttonB.setStyle("-fx-background-color: #B6D7C6");
                            }
                            break;
                        case 'C':
                            var amountC = c.getText();
                            amount = Integer.parseInt(amountC);
                            if(amount == 0){
                                buttonC.setStyle("-fx-background-color: #B6D7C6");
                            }
                            break;
                        case 'D':
                            var amountD = d.getText();
                            amount = Integer.parseInt(amountD);
                            if(amount == 0){
                                buttonD.setStyle("-fx-background-color: #B6D7C6");
                            }
                            break;
                        case 'E':
                            vowel = true;
                            var amountE = e.getText();
                            amount = Integer.parseInt(amountE);
                            if(amount == 0){
                                buttonE.setStyle("-fx-background-color: #B6D7C6");
                            }
                            break;
                        case 'F':
                            var amountF = f.getText();
                            amount = Integer.parseInt(amountF);
                            if(amount == 0){
                                buttonF.setStyle("-fx-background-color: #B6D7C6");
                            }
                            break;
                        case 'G':
                            var amountG = g.getText();
                            amount = Integer.parseInt(amountG);
                            if(amount == 0){
                                buttonG.setStyle("-fx-background-color: #B6D7C6");
                            }
                            break;
                        case 'H':
                            var amountH = h.getText();
                            amount = Integer.parseInt(amountH);
                            if(amount == 0){
                                buttonH.setStyle("-fx-background-color: #B6D7C6");
                            }
                            break;
                        case 'I':
                            vowel = true;
                            var amountI = i.getText();
                            amount = Integer.parseInt(amountI);
                            if(amount == 0){
                                buttonI.setStyle("-fx-background-color: #B6D7C6");
                            }
                            break;
                        case 'J':
                            var amountJ = j.getText();
                            amount = Integer.parseInt(amountJ);
                            if(amount == 0){
                                buttonJ.setStyle("-fx-background-color: #B6D7C6");
                            }
                            break;
                        case 'K':
                            var amountK = k.getText();
                            amount = Integer.parseInt(amountK);
                            if(amount == 0){
                                buttonK.setStyle("-fx-background-color: #B6D7C6");
                            }
                            break;
                        case 'L':
                            var amountL = l.getText();
                            amount = Integer.parseInt(amountL);
                            if(amount == 0){
                                buttonL.setStyle("-fx-background-color: #B6D7C6");
                            }
                            break;
                        case 'M':
                            var amountM = m.getText();
                            amount = Integer.parseInt(amountM);
                            if(amount == 0){
                                buttonM.setStyle("-fx-background-color: #B6D7C6");
                            }
                            break;
                        case 'N':
                            var amountN = n.getText();
                            amount = Integer.parseInt(amountN);
                            if(amount == 0){
                                buttonN.setStyle("-fx-background-color: #B6D7C6");
                            }
                            break;
                        case 'O':
                            vowel = true;
                            var amountO = o.getText();
                            amount = Integer.parseInt(amountO);
                            if(amount == 0){
                                buttonO.setStyle("-fx-background-color: #B6D7C6");
                            }
                            break;
                        case 'P':
                            var amountP = p.getText();
                            amount = Integer.parseInt(amountP);
                            if(amount == 0){
                                buttonP.setStyle("-fx-background-color: #B6D7C6");
                            }
                            break;
                        case 'Q':
                            var amountQ = q.getText();
                            amount = Integer.parseInt(amountQ);
                            if(amount == 0){
                                buttonQ.setStyle("-fx-background-color: #B6D7C6");
                            }
                            break;
                        case 'R':
                            var amountR = r.getText();
                            amount = Integer.parseInt(amountR);
                            if(amount == 0){
                                buttonR.setStyle("-fx-background-color: #B6D7C6");
                            }
                            break;
                        case 'S':
                            var amountS = s.getText();
                            amount = Integer.parseInt(amountS);
                            if(amount == 0){
                                buttonS.setStyle("-fx-background-color: #B6D7C6");
                            }
                            break;
                        case 'T':
                            var amountT = t.getText();
                            amount = Integer.parseInt(amountT);
                            if(amount == 0){
                                buttonT.setStyle("-fx-background-color: #B6D7C6");
                            }
                            break;
                        case 'U':
                            vowel = true;
                            var amountU = u.getText();
                            amount = Integer.parseInt(amountU);
                            if(amount == 0){
                                buttonU.setStyle("-fx-background-color: #B6D7C6");
                            }
                            break;
                        case 'V':
                            var amountV = v.getText();
                            amount = Integer.parseInt(amountV);
                            if(amount == 0){
                                buttonV.setStyle("-fx-background-color: #B6D7C6");
                            }
                            break;
                        case 'W':
                            var amountW = w.getText();
                            amount = Integer.parseInt(amountW);
                            if(amount == 0){
                                buttonW.setStyle("-fx-background-color: #B6D7C6");
                            }
                            break;
                        case 'X':
                            var amountX = x.getText();
                            amount = Integer.parseInt(amountX);
                            if(amount == 0){
                                buttonX.setStyle("-fx-background-color: #B6D7C6");
                            }
                            break;
                        case 'Y':
                            vowel = true;
                            var amountY = y.getText();
                            amount = Integer.parseInt(amountY);
                            if(amount == 0){
                                buttonY.setStyle("-fx-background-color: #B6D7C6");
                            }
                            break;
                        case 'Z':
                            var amountZ = z.getText();
                            amount = Integer.parseInt(amountZ);
                            if(amount == 0){
                                buttonZ.setStyle("-fx-background-color: #B6D7C6");
                            }
                            break;
                    }




                }
                //check to see if there are still enough tiles and enough vowels to keep playing
                if((vowelsLeft == 0) || (tilesLeft < 2)){
                    errorMsg.setText("Game Over");
                    System.out.println(vowelsLeft);
                    System.out.println(tilesLeft);
                }


            }else{

                // if the word is not valid, then set the amount of letters left back to how they were before verifying the word.
                for (var count = 0; count < word.length(); count++) {
                    var letter = word.charAt(count);
                    String newAmount;
                    int amount;
                    switch(letter){
                        case 'A':
                            var amountA = a.getText();
                            amount = Integer.parseInt(amountA);
                            amount += 1;
                            newAmount = Integer.toString(amount);
                            a.setText(newAmount);
                            tilesLeft += 1;
                            vowelsLeft += 1;
                            break;
                        case 'B':
                            var amountB = b.getText();
                            amount = Integer.parseInt(amountB);
                            amount += 1;
                            newAmount = Integer.toString(amount);
                            b.setText(newAmount);
                            tilesLeft += 1;

                            break;
                        case 'C':
                            var amountC = c.getText();
                            amount = Integer.parseInt(amountC);
                            amount += 1;
                            newAmount = Integer.toString(amount);
                            c.setText(newAmount);
                            tilesLeft += 1;

                            break;
                        case 'D':
                            var amountD = d.getText();
                            amount = Integer.parseInt(amountD);
                            amount += 1;
                            newAmount = Integer.toString(amount);
                            d.setText(newAmount);
                            tilesLeft += 1;

                            break;
                        case 'E':
                            var amountE = e.getText();
                            amount = Integer.parseInt(amountE);
                            amount += 1;
                            newAmount = Integer.toString(amount);
                            e.setText(newAmount);
                            tilesLeft += 1;
                            vowelsLeft += 1;
                            break;
                        case 'F':
                            var amountF = f.getText();
                            amount = Integer.parseInt(amountF);
                            amount += 1;
                            newAmount = Integer.toString(amount);
                            f.setText(newAmount);
                            tilesLeft += 1;

                            break;
                        case 'G':
                            var amountG = g.getText();
                            amount = Integer.parseInt(amountG);
                            amount += 1;
                            newAmount = Integer.toString(amount);
                            g.setText(newAmount);
                            tilesLeft += 1;

                            break;
                        case 'H':
                            var amountH = h.getText();
                            amount = Integer.parseInt(amountH);
                            amount += 1;
                            newAmount = Integer.toString(amount);
                            h.setText(newAmount);
                            tilesLeft += 1;

                            break;
                        case 'I':
                            var amountI = i.getText();
                            amount = Integer.parseInt(amountI);
                            amount += 1;
                            newAmount = Integer.toString(amount);
                            i.setText(newAmount);
                            tilesLeft += 1;
                            vowelsLeft += 1;
                            break;
                        case 'J':
                            var amountJ = j.getText();
                            amount = Integer.parseInt(amountJ);
                            amount += 1;
                            newAmount = Integer.toString(amount);
                            j.setText(newAmount);
                            tilesLeft += 1;

                            break;
                        case 'K':
                            var amountK = k.getText();
                            amount = Integer.parseInt(amountK);
                            amount += 1;
                            newAmount = Integer.toString(amount);
                            k.setText(newAmount);
                            tilesLeft += 1;

                            break;
                        case 'L':
                            var amountL = l.getText();
                            amount = Integer.parseInt(amountL);
                            amount += 1;
                            newAmount = Integer.toString(amount);
                            l.setText(newAmount);
                            tilesLeft += 1;

                            break;
                        case 'M':
                            var amountM = m.getText();
                            amount = Integer.parseInt(amountM);
                            amount += 1;
                            newAmount = Integer.toString(amount);
                            m.setText(newAmount);
                            tilesLeft += 1;

                            break;
                        case 'N':
                            var amountN = n.getText();
                            amount = Integer.parseInt(amountN);
                            amount += 1;
                            newAmount = Integer.toString(amount);
                            n.setText(newAmount);
                            tilesLeft += 1;

                            break;
                        case 'O':
                            var amountO = o.getText();
                            amount = Integer.parseInt(amountO);
                            amount += 1;
                            newAmount = Integer.toString(amount);
                            o.setText(newAmount);
                            tilesLeft += 1;
                            vowelsLeft += 1;
                            break;
                        case 'P':
                            var amountP = p.getText();
                            amount = Integer.parseInt(amountP);
                            amount += 1;
                            newAmount = Integer.toString(amount);
                            p.setText(newAmount);
                            tilesLeft += 1;

                            break;
                        case 'Q':
                            var amountQ = q.getText();
                            amount = Integer.parseInt(amountQ);
                            amount += 1;
                            newAmount = Integer.toString(amount);
                            q.setText(newAmount);
                            tilesLeft += 1;

                            break;
                        case 'R':
                            var amountR = r.getText();
                            amount = Integer.parseInt(amountR);
                            amount += 1;
                            newAmount = Integer.toString(amount);
                            r.setText(newAmount);
                            tilesLeft += 1;

                            break;
                        case 'S':
                            var amountS = s.getText();
                            amount = Integer.parseInt(amountS);
                            amount += 1;
                            newAmount = Integer.toString(amount);
                            s.setText(newAmount);
                            tilesLeft += 1;

                            break;
                        case 'T':
                            var amountT = t.getText();
                            amount = Integer.parseInt(amountT);
                            amount += 1;
                            newAmount = Integer.toString(amount);
                            t.setText(newAmount);
                            tilesLeft += 1;

                            break;
                        case 'U':
                            var amountU = u.getText();
                            amount = Integer.parseInt(amountU);
                            amount += 1;
                            newAmount = Integer.toString(amount);
                            u.setText(newAmount);
                            tilesLeft += 1;
                            vowelsLeft += 1;
                            break;
                        case 'V':
                            var amountV = v.getText();
                            amount = Integer.parseInt(amountV);
                            amount += 1;
                            newAmount = Integer.toString(amount);
                            v.setText(newAmount);
                            tilesLeft += 1;

                            break;
                        case 'W':
                            var amountW = w.getText();
                            amount = Integer.parseInt(amountW);
                            amount += 1;
                            newAmount = Integer.toString(amount);
                            w.setText(newAmount);
                            tilesLeft += 1;

                            break;
                        case 'X':
                            var amountX = x.getText();
                            amount = Integer.parseInt(amountX);
                            amount += 1;
                            newAmount = Integer.toString(amount);
                            x.setText(newAmount);
                            tilesLeft += 1;

                            break;
                        case 'Y':
                            var amountY = y.getText();
                            amount = Integer.parseInt(amountY);
                            amount += 1;
                            newAmount = Integer.toString(amount);
                            y.setText(newAmount);
                            tilesLeft += 1;
                            vowelsLeft += 1;
                            break;
                        case 'Z':
                            var amountZ = z.getText();
                            amount = Integer.parseInt(amountZ);
                            amount += 1;
                            newAmount = Integer.toString(amount);
                            z.setText(newAmount);
                            tilesLeft += 1;

                            break;
                    }




                }
            }
        }
        // set error messages if words don't meet the criteria
        System.out.println("valid: "+ validWord + " vowel: " + vowel + " unused: " + unused + " length: " + word.length() + " word: " + word);
        if(!validWord){
            errorMsg.setText("Words can only include available letters left in the bag.");
        }
        if(!vowel){
            errorMsg.setText("Words must contain a vowel.");
        }
        if(!unused){
            errorMsg.setText("This word has already been used.");
        }
        if(word.length() < 2){
            errorMsg.setText("Words must be at least 2 letters long.");
        }
        if(word.length() > 8){
            errorMsg.setText("Words must not exceed 8 letters.");
        }




    }



}



